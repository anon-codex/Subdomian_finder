<?php

$data = file_get_contents("php://input");
$data = json_decode($data);
$data = $data->sub;

// echo $data;

$GLOBALS["count"] = 0;
rosm($data);
# curl.php

function rosm($data){

// Initialize a connection with cURL (ch = cURL handle, or "channel")
$ch = curl_init();

// Set the URL
curl_setopt($ch, CURLOPT_URL, $data);
// $GLOBALS['count']++;

// Set the HTTP method
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

// Return the response instead of printing it out
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

// curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
// curl_setopt($ch, CURLOPT_TIMEOUT, 10); 
// Send the request and store the result in $response
// $GLOBALS['count']++;
$response = curl_exec($ch);

if(curl_getinfo($ch,CURLINFO_HTTP_CODE) >= 200 && curl_getinfo($ch,CURLINFO_HTTP_CODE) < 300){
   // echo "<span>".$data. ",<span style='color:green'>(Status-Code:".curl_getinfo($ch, CURLINFO_HTTP_CODE).")</span></span>";

    
    echo "<div class='subo'> 
    <span>$data</span>"."<label style='color:green'>(Status-Code:".curl_getinfo($ch, CURLINFO_HTTP_CODE).")</label>".
  "</div>";
}
else if(curl_getinfo($ch,CURLINFO_HTTP_CODE) >= 300 && curl_getinfo($ch,CURLINFO_HTTP_CODE) < 400)
{
   // echo "<span>".$data. ",<span style='color:yellow'>(Status-Code:".curl_getinfo($ch, CURLINFO_HTTP_CODE).")</span></span>";

    echo "<div class='subo'> 
    <span>$data</span>"."<label style='color:yellow'>(Status-Code:".curl_getinfo($ch, CURLINFO_HTTP_CODE).")</label>".
  "</div>";
}
else if(curl_getinfo($ch,CURLINFO_HTTP_CODE) >= 400 && curl_getinfo($ch,CURLINFO_HTTP_CODE) < 500)
{
    //echo "<span>".$data. ",<span style='color:red'>(Status-Code:".curl_getinfo($ch, CURLINFO_HTTP_CODE).")</span></span>";

    echo "<div class='subo'> 
    <span>$data</span>"."<label style='color:red'>(Status-Code:".curl_getinfo($ch, CURLINFO_HTTP_CODE).")</label>".
  "</div>";
}
else if(curl_getinfo($ch,CURLINFO_HTTP_CODE) >= 500)
{
    echo "<span>".$data. ",<span style='color:blue'>(Status-Code:".curl_getinfo($ch, CURLINFO_HTTP_CODE).")</span></span>";
}
else{
    echo $GLOBALS['count']++;
}
// echo 'Response Body: ' . $response . PHP_EOL;

// Close cURL resource to free up system resources
curl_close($ch);
$GLOBALS['count']++;
}


?>